/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package canteen.management;

/**
 *
 * @author Emilia
 */
public class CANTEENMANAGEMENT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Homepage2 Homepage2frame = new Homepage2 ();
       Homepage2frame.setVisible(true);
      
       
    
    }
    
}
